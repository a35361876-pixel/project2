# RememberAI — Vercel 배포 가이드

이 ZIP 패키지에는 프론트엔드(Vite + React + Tailwind CSS)와 백엔드 API(`api/[...all].ts` → `serverApp.ts`)가 Vercel Serverless Functions 구조로 함께 포함되어 있습니다.

## 1. Vercel 프로젝트 생성 및 업로드
1. 압축을 푼 폴더를 GitHub/GitLab 저장소에 푸시한 뒤 Vercel에서 **Add New Project**로 Import 하거나, Vercel CLI(`npx vercel --prod`)로 바로 배포합니다.
2. **Framework Preset**은 자동으로 `Vite`로 감지됩니다 (`vercel.json` 포함).
   - Build Command: `npm run build`
   - Output Directory: `dist`

## 2. 필수 환경 변수 설정 (Vercel Dashboard)
**Project Settings → Environment Variables**에 아래 값을 추가한 뒤 재배포(Redeploy)하세요.
- `GEMINI_API_KEY`: Google AI Studio에서 발급받은 Gemini API 키 (퀴즈 생성, OCR 스캔, 빈칸 퀴즈, 백지 인출 채점에 필수)

## 3. Firebase Google 로그인 도메인 승인 (중요)
Vercel 배포 주소(`https://프로젝트명.vercel.app`)에서 Google 로그인 팝업이 정상 동작하려면 Firebase Console에 도메인을 등록해야 합니다.
1. [Firebase Console](https://console.firebase.google.com/) 접속 → 프로젝트 선택
2. **Authentication → Settings → Authorized domains** 이동
3. **Add domain**을 눌러 배포된 Vercel 도메인(예: `rememberai.vercel.app` 또는 커스텀 도메인)을 추가합니다.
4. `firestore.rules`를 수정한 경우 `firebase deploy --only firestore:rules`로 규칙을 반영하세요.

## 4. 로컬 실행 방법
```bash
npm install
cp .env.example .env
# .env 파일에 GEMINI_API_KEY 입력
npm run dev
```
