# RememberAI (리멤버AI)

에빙하우스 망각곡선($R = e^{-t/k}$)을 기준선으로 두고, 브라우저 내 경량 인공신경망(MLP)이 사용자의 실제 복습 결과·난이도·경과 시간·반복 횟수·약점 극복 여부를 학습해 개인 맞춤형 망각곡선과 복습 골든타임을 예측하는 AI 에듀테크 웹 애플리케이션입니다.

## 주요 기능
- **2단계 하이브리드 망각곡선 보정**: 표준 에빙하우스 기준선 + 4-4-1 Residual MLP 실시간 역전파 보정 및 군집(암기·어휘 / 이해·개념 / 수식·문제풀이) 초기 가중치 반영
- **대시보드 7일 추이 & 복습 일정 달력**: 지난 7일간 학습 성취도·기억 잔존율 변화 Line Chart 및 구체적 복습 날짜/시간 달력
- **Gemini AI 기반 퀴즈·OCR·NLP 분석**: Google Search 연계 난이도별 4지선다 퀴즈, 필기·문제집 이미지 OCR 스캔, 맞춤형 빈칸 채우기 퀴즈 생성
- **백지 인출 & 약점 재도전 루프**: 텍스트·펜·지우개 캔버스로 백지 인출 후 Gemini AI가 잘 기억한 점/부족한 점/점수를 분석하고, 수집된 약점만을 주제로 집중 재도전 가능
- **시험 직전 자원 배분 최적화 & XAI 패널**: D-Day 및 가용 시간 기반 최적 복습 조합(0/1 Knapsack) 산출 및 신경망 가중치 변화 로그 제공
- **Firebase Google 로그인 & Cloud Firestore 동기화**: 비로그인 체험 모드(로컬 저장) 및 로그인 시 실시간 클라우드 동기화 지원

## 로컬 실행 방법
```bash
npm install
cp .env.example .env
# .env 파일에 GEMINI_API_KEY 값을 입력합니다.
npm run dev
```
- 개발 서버: `http://localhost:3000`

## GitHub → Vercel 배포 안내
1. 이 프로젝트 폴더를 GitHub 저장소에 업로드(Push)합니다. (`.env` 비밀키는 `.gitignore`에 의해 제외됩니다.)
2. [Vercel](https://vercel.com/)에서 해당 GitHub 저장소를 Import합니다. (`vercel.json` 및 `api/[...all].ts`가 자동 인식됩니다.)
3. Vercel **Project Settings → Environment Variables**에 `GEMINI_API_KEY`를 등록한 뒤 배포합니다.
4. [Firebase Console](https://console.firebase.google.com/) → **Authentication → Settings → Authorized domains**에 배포된 Vercel 도메인을 추가합니다.
