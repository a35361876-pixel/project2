import React, { useMemo, useRef, useState } from 'react';
import { TrendingDown, TrendingUp } from 'lucide-react';
import {
  DailyProgressPoint,
  MLPWeights,
  StudyCard,
  TrainingLogEntry,
  WeaknessPointItem,
} from '../types';
import { buildSevenDayProgressSeries, RETENTION_THRESHOLD } from '../lib/mlp';

type SeriesFilter = 'both' | 'achievement' | 'retention';

interface WeeklyProgressLineChartProps {
  cards: StudyCard[];
  weights: MLPWeights;
  logs: TrainingLogEntry[];
  weakPoints: WeaknessPointItem[];
  onOpenAddModal: () => void;
  onResetDemo: () => void;
}

export const WeeklyProgressLineChart: React.FC<WeeklyProgressLineChartProps> = ({
  cards,
  weights,
  logs,
  weakPoints,
  onOpenAddModal,
  onResetDemo,
}) => {
  const [seriesFilter, setSeriesFilter] = useState<SeriesFilter>('both');
  const [inspectIdx, setInspectIdx] = useState<number | null>(null);
  const svgRef = useRef<SVGSVGElement | null>(null);

  const series = useMemo<DailyProgressPoint[]>(
    () => buildSevenDayProgressSeries(cards, weights, logs, weakPoints),
    [cards, weights, logs, weakPoints]
  );

  const firstPoint = series[0];
  const latestPoint = series[series.length - 1];

  const retentionDelta = useMemo(() => {
    if (!firstPoint || !latestPoint) return 0;
    return Number((latestPoint.retentionPct - firstPoint.retentionPct).toFixed(1));
  }, [firstPoint, latestPoint]);

  const achievementDelta = useMemo(() => {
    if (!firstPoint || !latestPoint) return 0;
    return Number((latestPoint.achievementPct - firstPoint.achievementPct).toFixed(1));
  }, [firstPoint, latestPoint]);

  const avgAchievement7d = useMemo(() => {
    if (series.length === 0) return 0;
    const sum = series.reduce((acc, pt) => acc + pt.achievementPct, 0);
    return Number((sum / series.length).toFixed(1));
  }, [series]);

  const totalReviews7d = useMemo(
    () => series.reduce((acc, pt) => acc + pt.reviewCount, 0),
    [series]
  );

  // SVG Coordinate System
  const width = 700;
  const height = 228;
  const pad = { top: 20, right: 24, bottom: 38, left: 46 };
  const plotW = width - pad.left - pad.right;
  const plotH = height - pad.top - pad.bottom;

  const xScale = (idx: number) =>
    pad.left + (series.length <= 1 ? 0 : (idx / (series.length - 1)) * plotW);
  const yScale = (pct: number) =>
    pad.top + (1 - Math.max(0, Math.min(100, pct)) / 100) * plotH;

  const {
    retentionPath,
    retentionAreaPath,
    achievementPath,
    achievementAreaPath,
  } = useMemo(() => {
    if (series.length === 0) {
      return {
        retentionPath: '',
        retentionAreaPath: '',
        achievementPath: '',
        achievementAreaPath: '',
      };
    }

    const rParts: string[] = [];
    const aParts: string[] = [];
    const baseY = yScale(0).toFixed(1);

    for (let i = 0; i < series.length; i++) {
      const x = xScale(i).toFixed(1);
      const ry = yScale(series[i].retentionPct).toFixed(1);
      const ay = yScale(series[i].achievementPct).toFixed(1);
      rParts.push(`${i === 0 ? 'M' : 'L'} ${x} ${ry}`);
      aParts.push(`${i === 0 ? 'M' : 'L'} ${x} ${ay}`);
    }

    const firstX = xScale(0).toFixed(1);
    const lastX = xScale(series.length - 1).toFixed(1);

    return {
      retentionPath: rParts.join(' '),
      retentionAreaPath: `${rParts.join(' ')} L ${lastX} ${baseY} L ${firstX} ${baseY} Z`,
      achievementPath: aParts.join(' '),
      achievementAreaPath: `${aParts.join(' ')} L ${lastX} ${baseY} L ${firstX} ${baseY} Z`,
    };
  }, [series]);

  const handlePointer = (clientX: number) => {
    if (!svgRef.current || series.length === 0) return;
    const rect = svgRef.current.getBoundingClientRect();
    const relX = ((clientX - rect.left) / Math.max(1, rect.width)) * width;
    const clamped = Math.max(pad.left, Math.min(width - pad.right, relX));
    const ratio = (clamped - pad.left) / Math.max(1, plotW);
    const idx = Math.max(0, Math.min(series.length - 1, Math.round(ratio * (series.length - 1))));
    setInspectIdx(idx);
  };

  const activeIdx = inspectIdx !== null ? inspectIdx : Math.max(0, series.length - 1);
  const activePoint = series[activeIdx];
  const yTicks = [100, 70, 50, 25, 0];
  const thresholdY = yScale(RETENTION_THRESHOLD * 100);

  const showRetention = seriesFilter === 'both' || seriesFilter === 'retention';
  const showAchievement = seriesFilter === 'both' || seriesFilter === 'achievement';

  return (
    <section
      aria-label="지난 7일간 학습 성취도와 기억 잔존율 변화"
      className="bg-white border border-slate-200 rounded-2xl p-4 sm:p-5 space-y-4"
    >
      {/* Header Row */}
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h2 className="text-base sm:text-lg font-bold text-slate-900 tracking-tight">
            지난 7일 학습 성취도 · 기억 잔존율 변화
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            최근 7일간 복습·백지 인출 성취도와 AI 보정 평균 기억 잔존율(%) 추이를 비교합니다.
          </p>
        </div>

        {/* Series Segmented Filter */}
        <div
          role="group"
          aria-label="차트 지표 선택"
          className="inline-flex items-center gap-1 p-1 bg-slate-100 rounded-xl shrink-0"
        >
          <button
            type="button"
            onClick={() => setSeriesFilter('both')}
            className={`px-3 py-1.5 min-h-[36px] text-xs font-semibold rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              seriesFilter === 'both'
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            전체
          </button>
          <button
            type="button"
            onClick={() => setSeriesFilter('achievement')}
            className={`px-3 py-1.5 min-h-[36px] text-xs font-semibold rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              seriesFilter === 'achievement'
                ? 'bg-white text-emerald-700 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            학습 성취도
          </button>
          <button
            type="button"
            onClick={() => setSeriesFilter('retention')}
            className={`px-3 py-1.5 min-h-[36px] text-xs font-semibold rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              seriesFilter === 'retention'
                ? 'bg-white text-blue-700 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            기억 잔존율
          </button>
        </div>
      </div>

      {cards.length === 0 ? (
        <div className="py-8 px-4 rounded-xl bg-slate-50 border border-slate-200/80 text-center space-y-3">
          <p className="text-sm font-semibold text-slate-800">
            추적할 학습 과목이 없어 7일 추이를 표시할 수 없습니다.
          </p>
          <p className="text-xs text-slate-500">
            새 과목을 등록하거나 샘플 과목을 불러오면 7일간 기억 잔존율과 학습 성취도 변화를 확인할 수 있습니다.
          </p>
          <div className="flex flex-wrap items-center justify-center gap-2 pt-1">
            <button
              type="button"
              onClick={onOpenAddModal}
              className="px-4 py-2 min-h-[40px] text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-xl transition-colors whitespace-nowrap cursor-pointer"
            >
              + 새 과목 추가하기
            </button>
            <button
              type="button"
              onClick={onResetDemo}
              className="px-4 py-2 min-h-[40px] text-xs font-semibold text-slate-700 bg-white border border-slate-200 hover:bg-slate-100 rounded-xl transition-colors whitespace-nowrap cursor-pointer"
            >
              샘플 과목 다시 불러오기
            </button>
          </div>
        </div>
      ) : (
        <>
          {/* 3-Column Summary Strip (Unboxed with hairlines, tabular numerals) */}
          <div className="grid grid-cols-3 divide-x divide-slate-200 border-y border-slate-100 py-2.5 text-xs tabular-nums">
            <div className="pr-2 sm:pr-4">
              <div className="text-[11px] text-slate-500">오늘 기억 잔존율</div>
              <div className="flex flex-wrap items-baseline gap-1.5 mt-0.5">
                <span className="text-base sm:text-lg font-bold font-mono-tabular text-blue-700">
                  {latestPoint ? `${latestPoint.retentionPct.toFixed(1)}%` : '—'}
                </span>
                <span
                  className={`inline-flex items-center gap-0.5 text-[11px] font-semibold font-mono-tabular ${
                    retentionDelta >= 0 ? 'text-blue-600' : 'text-rose-600'
                  }`}
                >
                  {retentionDelta >= 0 ? (
                    <TrendingUp className="w-3 h-3" aria-hidden="true" />
                  ) : (
                    <TrendingDown className="w-3 h-3" aria-hidden="true" />
                  )}
                  {retentionDelta >= 0 ? `+${retentionDelta}%p` : `${retentionDelta}%p`}
                </span>
              </div>
            </div>

            <div className="px-2 sm:px-4">
              <div className="text-[11px] text-slate-500">7일 평균 학습 성취도</div>
              <div className="flex flex-wrap items-baseline gap-1.5 mt-0.5">
                <span className="text-base sm:text-lg font-bold font-mono-tabular text-emerald-700">
                  {avgAchievement7d.toFixed(1)}%
                </span>
                <span
                  className={`inline-flex items-center gap-0.5 text-[11px] font-semibold font-mono-tabular ${
                    achievementDelta >= 0 ? 'text-emerald-600' : 'text-amber-700'
                  }`}
                >
                  {achievementDelta >= 0 ? (
                    <TrendingUp className="w-3 h-3" aria-hidden="true" />
                  ) : (
                    <TrendingDown className="w-3 h-3" aria-hidden="true" />
                  )}
                  {achievementDelta >= 0 ? `+${achievementDelta}%p` : `${achievementDelta}%p`}
                </span>
              </div>
            </div>

            <div className="pl-2 sm:pl-4">
              <div className="text-[11px] text-slate-500">최근 7일 완료 복습</div>
              <div className="flex flex-wrap items-baseline gap-1.5 mt-0.5">
                <span className="text-base sm:text-lg font-bold font-mono-tabular text-slate-900">
                  {totalReviews7d}회
                </span>
                <span className="text-[11px] text-slate-500 truncate">
                  {cards.length}개 과목 추적
                </span>
              </div>
            </div>
          </div>

          {/* Interactive SVG 7-Day Line Chart */}
          <div className="relative w-full overflow-hidden">
            <svg
              ref={svgRef}
              viewBox={`0 0 ${width} ${height}`}
              className="w-full h-auto touch-none select-none cursor-crosshair"
              onPointerMove={(e) => handlePointer(e.clientX)}
              onPointerDown={(e) => handlePointer(e.clientX)}
              onPointerLeave={() => setInspectIdx(null)}
            >
              {/* Horizontal Grid Lines & 70% Golden Threshold */}
              {yTicks.map((tick) => {
                const y = yScale(tick);
                const isThreshold = tick === 70;
                return (
                  <g key={tick}>
                    <line
                      x1={pad.left}
                      y1={y}
                      x2={width - pad.right}
                      y2={y}
                      stroke={isThreshold ? '#DC2626' : '#E2E8F0'}
                      strokeWidth={isThreshold ? 1.4 : 1}
                      strokeDasharray={isThreshold ? '4 4' : undefined}
                      opacity={isThreshold ? 0.65 : 1}
                    />
                    <text
                      x={pad.left - 8}
                      y={y + 4}
                      textAnchor="end"
                      className="text-[11px] font-mono-tabular"
                      fill={isThreshold ? '#DC2626' : '#64748B'}
                      fontWeight={isThreshold ? 600 : 400}
                    >
                      {tick}%
                    </text>
                  </g>
                );
              })}

              {/* 70% Threshold Caption */}
              <text
                x={width - pad.right}
                y={thresholdY - 6}
                textAnchor="end"
                className="text-[10px] font-medium"
                fill="#DC2626"
              >
                목표 기준선 (70%)
              </text>

              {/* Vertical Grid & Date Ticks */}
              {series.map((pt, i) => {
                const x = xScale(i);
                const isInspected = i === activeIdx;
                return (
                  <g key={pt.dateKey}>
                    <line
                      x1={x}
                      y1={pad.top}
                      x2={x}
                      y2={yScale(0)}
                      stroke={isInspected ? '#CBD5E1' : '#F1F5F9'}
                      strokeWidth={isInspected ? 1.5 : 1}
                    />
                    <text
                      x={x}
                      y={height - 14}
                      textAnchor="middle"
                      className="text-[11px] font-mono-tabular"
                      fill={pt.isToday || isInspected ? '#0F172A' : '#64748B'}
                      fontWeight={pt.isToday || isInspected ? 700 : 400}
                    >
                      {pt.shortLabel}
                    </text>
                  </g>
                );
              })}

              {/* Area Fills */}
              {showAchievement && achievementAreaPath && (
                <path d={achievementAreaPath} fill="#059669" fillOpacity="0.07" />
              )}
              {showRetention && retentionAreaPath && (
                <path d={retentionAreaPath} fill="#2563EB" fillOpacity="0.08" />
              )}

              {/* Line 2: Learning Achievement (%) */}
              {showAchievement && achievementPath && (
                <path
                  d={achievementPath}
                  fill="none"
                  stroke="#059669"
                  strokeWidth={2.75}
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              )}

              {/* Line 1: Memory Retention (%) */}
              {showRetention && retentionPath && (
                <path
                  d={retentionPath}
                  fill="none"
                  stroke="#2563EB"
                  strokeWidth={2.75}
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              )}

              {/* Data Points */}
              {series.map((pt, i) => {
                const x = xScale(i);
                const isActive = i === activeIdx;
                return (
                  <g key={`pts-${pt.dateKey}`}>
                    {showAchievement && (
                      <circle
                        cx={x}
                        cy={yScale(pt.achievementPct)}
                        r={isActive ? 5.5 : 3.75}
                        fill={isActive ? '#059669' : '#FFFFFF'}
                        stroke="#059669"
                        strokeWidth={2.25}
                      />
                    )}
                    {showRetention && (
                      <circle
                        cx={x}
                        cy={yScale(pt.retentionPct)}
                        r={isActive ? 5.5 : 3.75}
                        fill={isActive ? '#2563EB' : '#FFFFFF'}
                        stroke="#2563EB"
                        strokeWidth={2.25}
                      />
                    )}
                  </g>
                );
              })}
            </svg>
          </div>

          {/* Interactive Selected Day Readout & Legend */}
          <div className="flex flex-wrap items-center justify-between gap-2 px-3.5 py-2.5 rounded-xl bg-slate-50 border border-slate-200/80 text-xs tabular-nums">
            <div className="flex flex-wrap items-center gap-x-3 gap-y-1">
              <span className="font-bold text-slate-900">
                {activePoint?.fullLabel ?? '오늘'}
              </span>
              {showRetention && activePoint && (
                <span className="text-slate-700">
                  기억 잔존율{' '}
                  <strong className="font-mono-tabular text-blue-700">
                    {activePoint.retentionPct.toFixed(1)}%
                  </strong>
                </span>
              )}
              {showAchievement && activePoint && (
                <span className="text-slate-700">
                  학습 성취도{' '}
                  <strong className="font-mono-tabular text-emerald-700">
                    {activePoint.achievementPct.toFixed(1)}%
                  </strong>
                </span>
              )}
            </div>

            <span className="text-[11px] text-slate-500">
              {activePoint && activePoint.reviewCount > 0
                ? `해당일 복습 ${activePoint.reviewCount}회 (평균 ${activePoint.avgLogScore ?? '—'}점)`
                : '망각곡선 모델 기준 추적'}
            </span>
          </div>

          {/* Legend */}
          <div className="flex flex-wrap items-center justify-between gap-3 pt-1 text-xs text-slate-600">
            <div className="flex flex-wrap items-center gap-4">
              {showRetention && (
                <div className="flex items-center gap-2">
                  <span className="inline-block w-5 border-t-[3px] border-blue-600 rounded-full" />
                  <span className="font-semibold text-slate-900">기억 잔존율 (%)</span>
                </div>
              )}
              {showAchievement && (
                <div className="flex items-center gap-2">
                  <span className="inline-block w-5 border-t-[3px] border-emerald-600 rounded-full" />
                  <span className="font-semibold text-slate-900">학습 성취도 (%)</span>
                </div>
              )}
              <div className="flex items-center gap-2">
                <span className="inline-block w-5 border-t-2 border-dashed border-red-600" />
                <span className="text-red-700 font-medium">70% 목표 기준선</span>
              </div>
            </div>
            <span className="text-[11px] text-slate-400">
              날짜 위를 터치·마우스로 이동해 일별 수치 확인
            </span>
          </div>
        </>
      )}
    </section>
  );
};
